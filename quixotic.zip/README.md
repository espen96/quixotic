# [quixotic](https://www.google.com/search?q=define+quixotic)
## /kwɪkˈsɒtɪk/
**adjective: quixotic**

extremely idealistic; unrealistic and impractical.

*"a vast and perhaps quixotic project"*
